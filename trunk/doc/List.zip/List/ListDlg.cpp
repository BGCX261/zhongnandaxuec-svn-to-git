// ListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "List.h"
#include "ListDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListDlg dialog

CListDlg::CListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CListDlg)
	m_sid = 0;
	m_sname = _T("");
	m_date = COleDateTime::GetCurrentTime();
	m_sex = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CListDlg)
	DDX_Control(pDX, IDC_btnUpd, m_btnUpd);
	DDX_Control(pDX, IDC_btnSelect, m_btnSelect);
	DDX_Control(pDX, IDC_btnSave, m_btnSave);
	DDX_Control(pDX, IDC_btnNew, m_btnNew);
	DDX_Control(pDX, IDC_btnCancel, m_btnCancel);
	DDX_Control(pDX, IDC_btnDel, m_btnDel);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX, IDC_EDIT1, m_sid);
	DDX_Text(pDX, IDC_EDIT2, m_sname);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER1, m_date);
    DDX_CBIndex(pDX, IDC_COMBO1, m_sex);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CListDlg, CDialog)
	//{{AFX_MSG_MAP(CListDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	ON_BN_CLICKED(IDC_btnSelect, OnbtnSelect)
	ON_BN_CLICKED(IDC_btnNew, OnbtnNew)
	ON_BN_CLICKED(IDC_btnUpd, OnbtnUpd)
	ON_BN_CLICKED(IDC_btnDel, OnbtnDel)
	ON_BN_CLICKED(IDC_btnCancel, OnbtnCancel)
	ON_BN_CLICKED(IDC_btnSave, OnbtnSave)
	ON_NOTIFY(NM_CLICK, IDC_LIST1, OnClickList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListDlg message handlers
//����ö�ٱ�����ʵ�ֶԲ�ͬ���ܵ�����
//
enum enumCHO
{
		NONE,		//��Ӧû�й���
		SEARCH,		//��Ӧ���ҹ���
		add,		//��Ӧ���ӹ���
		DEL,		//��Ӧɾ������
		MODIFY,		//��Ӧ�޸Ĺ���
};

//����ö�ٱ���FOUNCTION
enumCHO FOUNCTION = NONE;
int irow=-1;

BOOL CListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.
    //��ʼ���б�����
	m_list.InsertColumn(0,"ѧ��",LVCFMT_CENTER,100);
	m_list.InsertColumn(1,"����",LVCFMT_CENTER,150);
	m_list.InsertColumn(2,"�Ա�",LVCFMT_CENTER,150);
	m_list.InsertColumn(3,"��ѧ����",LVCFMT_CENTER,200);
	m_list.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);

	m_pRrd.CreateInstance(__uuidof(Recordset));
	try
	{
		//��SQL���ݿ��д�STUDENTS��
		//	m_pcon->Open("driver={SQL Server};Server=(local);DATABASE=UGMS;UID=sa;PWD=sa","","",adModeUnknown);
		
		m_pRrd->Open("SELECT SID,SName,case SSex when 0 then '��' else 'Ů' end   SSex,convert(varchar(10),SComeDate,121) SComeDate FROM STUDENTS order by sid", 
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenDynamic,
			adLockOptimistic,
			adCmdText);
		
	}
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}

	try
	{
		if(!m_pRrd->BOF)
		{
			m_pRrd->MoveFirst();
		}
		else
		{
			MessageBox("����û�����ݣ�");
			return TRUE;
		}
		 //��������ʾ���б���
	    while(!m_pRrd->adoEOF)
		{
			int iItemCnt=0;
			iItemCnt=m_list.GetItemCount();
			m_list.InsertItem(iItemCnt,(_bstr_t)m_pRrd->GetCollect("SID"));
			m_list.SetItemText(iItemCnt,1,(_bstr_t)m_pRrd->GetCollect("SName"));
			m_list.SetItemText(iItemCnt,2,(_bstr_t)m_pRrd->GetCollect("SSex"));
			m_list.SetItemText(iItemCnt,3,(_bstr_t)m_pRrd->GetCollect("SComeDate"));
			m_pRrd->MoveNext();
			
		}
	}
	catch (CMemoryException* e)
	{
		
	}

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CListDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CListDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CListDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//////////////////////
//˫���б��н�������ʾ����ϸ��
///////////////////////
void CListDlg::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int i=m_list.GetSelectionMark();

//	MessageBox(m_list.GetItemText(i,0)+","+m_list.GetItemText(i,1));
    m_sid=atoi(m_list.GetItemText(i,0));
	
	m_pOne.CreateInstance(__uuidof(Recordset));
	try
	{
		//��SQL���ݿ��д�STUDENTS��
		//	m_pcon->Open("driver={SQL Server};Server=(local);DATABASE=UGMS;UID=sa;PWD=sa","","",adModeUnknown);
		CString strsql;
		strsql.Format("SELECT SID,SName, SSex,SComeDate FROM STUDENTS where sid=%s",m_list.GetItemText(i,0));
		m_pOne->Open((_variant_t)strsql, 
			//m_pcon.GetInterfacePtr(),
			//theApp.m_pCon.GetInterfacePtr(),
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenDynamic,
			adLockOptimistic,
			adCmdText);
		
	}
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}

	if(!m_pOne ->BOF)
	{

		m_pOne->MoveFirst();
		_variant_t var;
		var=m_pOne->GetCollect("SName");
		m_sname=(LPCSTR)_bstr_t(var);
		var=m_pOne->GetCollect("SSex");
		m_sex=var.iVal;
		var=m_pOne->GetCollect("SComeDate");
		m_date=var.date;
	}

	UpdateData(FALSE);
	*pResult = 0;

}


void CListDlg::OnbtnSelect() 
{
	// TODO: Add your control notification handler code here
	FOUNCTION=SEARCH;
	Select();
	m_btnNew.EnableWindow(FALSE);
	m_btnUpd.EnableWindow(FALSE);
	m_btnDel.EnableWindow(FALSE);
	m_btnSave.EnableWindow(FALSE);
}

void CListDlg::OnbtnNew() 
{
	// TODO: Add your control notification handler code here
	FOUNCTION=add;
	m_btnSelect.EnableWindow(FALSE);
	m_btnUpd.EnableWindow(FALSE);
	m_btnDel.EnableWindow(FALSE);
	m_btnSave.EnableWindow(TRUE);
	m_sex=0;
	m_sid=0;
	m_sname=_T("");
	m_date=COleDateTime::GetCurrentTime();
	UpdateData(FALSE);
	
}

void CListDlg::OnbtnUpd() 
{

	// TODO: Add your control notification handler code here
	UpdateData();
	_variant_t var;
	//UpdateData();
	if(-1==irow)
	{
		MessageBox("û��ѡ������!");
		return;
	}
	else
	{
		//	MessageBox(m_list.GetItemText(i,0)+","+m_list.GetItemText(i,1));
		m_sid=atoi(m_list.GetItemText(irow,0));
	}
	m_btnSelect.EnableWindow(FALSE);
	m_btnNew.EnableWindow(FALSE);
	m_btnDel.EnableWindow(FALSE);
	m_btnSave.EnableWindow(TRUE);
	FOUNCTION=MODIFY;
	m_pOne.CreateInstance(__uuidof(Recordset));
	try
	{
		//��SQL���ݿ��д�STUDENTS��
		//	m_pcon->Open("driver={SQL Server};Server=(local);DATABASE=UGMS;UID=sa;PWD=sa","","",adModeUnknown);
		CString strsql;
		strsql.Format("SELECT SID,SName, SSex,SComeDate FROM STUDENTS where sid=%s",m_list.GetItemText(irow,0));
		m_pOne->Open((_variant_t)strsql, 		
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenDynamic,
			adLockOptimistic,
			adCmdText);
		
	}
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}

	if(!m_pOne ->BOF)
	{
		
		m_pOne->MoveFirst();
		_variant_t var;
		var=m_pOne->GetCollect("SName");
		m_sname=(LPCSTR)_bstr_t(var);
		var=m_pOne->GetCollect("SSex");
		m_sex=var.iVal;
		var=m_pOne->GetCollect("SComeDate");
		m_date=var.date;
		}
	UpdateData(FALSE);
}

void CListDlg::OnbtnDel() 
{
	// TODO: Add your control notification handler code here

	UpdateData();
	
	_variant_t var;
	//UpdateData();
	if(-1==irow)
	{
		MessageBox("û��ѡ������!");
		return;
	}
	else
	{
		
		//MessageBox(m_list.GetItemText(i,0)+","+m_list.GetItemText(i,1));
		m_sid=atoi(m_list.GetItemText(irow,0));
	}
	m_btnSelect.EnableWindow(FALSE);
	m_btnNew.EnableWindow(FALSE);
	m_btnUpd.EnableWindow(FALSE);
	m_btnSave.EnableWindow(TRUE);
	FOUNCTION=DEL;
	m_pOne.CreateInstance(__uuidof(Recordset));
	try
	{
		//��SQL���ݿ��д�STUDENTS��
		//	m_pcon->Open("driver={SQL Server};Server=(local);DATABASE=UGMS;UID=sa;PWD=sa","","",adModeUnknown);
		CString strsql;
		strsql.Format("SELECT SID,SName, SSex,SComeDate FROM STUDENTS where sid=%s",m_list.GetItemText(irow,0));
		m_pOne->Open((_variant_t)strsql, 
			//m_pcon.GetInterfacePtr(),
			//theApp.m_pCon.GetInterfacePtr(),
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenDynamic,
			adLockOptimistic,
			adCmdText);
		
	}
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}
	
	if(!m_pOne ->BOF)
	{
		
		m_pOne->MoveFirst();
		_variant_t var;
		var=m_pOne->GetCollect("SName");
		m_sname=(LPCSTR)_bstr_t(var);
		var=m_pOne->GetCollect("SSex");
		m_sex=var.iVal;
		var=m_pOne->GetCollect("SComeDate");
		m_date=var.date;
	}
	UpdateData(FALSE);
	if( TRUE==MessageBox("�Ƿ�Ҫɾ��!","��ʾ",MB_OK|MB_OKCANCEL))
	{		
        Del();
	}
}

void CListDlg::Add()
{
	UpdateData();
    if(m_sid ==0)
	{
		MessageBox("ѧ�Ų���Ϊ��");
		return;
	}

	m_pOne.CreateInstance(__uuidof(Recordset));
	
	try
	{
		//��SQL���ݿ��д�STUDENTS��
		//	m_pcon->Open("driver={SQL Server};Server=(local);DATABASE=UGMS;UID=sa;PWD=sa","","",adModeUnknown);
		CString strsql;
		_variant_t _vr;
		_vr.iVal=m_sid;
		CString strid;
		//MessageBox(m_sid+"");
		
		((CEdit*)GetDlgItem(IDC_EDIT1))->GetWindowText(strid);
		//MessageBox(strid);
		strsql="SELECT SID,SName FROM STUDENTS where sid ="+strid;
		m_pOne->Open((_variant_t)strsql, 			
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenDynamic,
			adLockOptimistic,
			adCmdText);
		
	}
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}

	if(!m_pOne->BOF)
	{
		MessageBox("��ѧ���Ѿ����ڣ�");
		return;

	}
	else{

		try
		{
			_variant_t vstrsex;
			vstrsex.iVal=m_sex;
			CString strid;
				((CEdit*)GetDlgItem(IDC_EDIT1))->GetWindowText(strid);
			CString strsex;
				if( m_sex==0)
					strsex="0";
				else
					strsex="1";
				_variant_t var;
				var=m_date;
				//(LPCSTR)_bstr_t(var)
		CString strdate;
		((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetWindowText(strdate);

			CString strsql="insert into STUDENTS(SID,SName,SSex,SComeDate) values("+ strid + ",'" \
				+ m_sname + "'," + strsex + ",'" + strdate+ "')";
			//MessageBox((char *)(_bstr_t)strsql);
			if ( m_pOne->State==adStateOpen)
				m_pOne->Close();
			m_pOne->Open((_variant_t)strsql,
				//m_pcon.GetInterfacePtr(),
				//theApp.m_pCon.GetInterfacePtr(),
				theApp.m_pConnection.GetInterfacePtr(),
				adOpenStatic,
				adLockOptimistic,
				adCmdUnknown);
			MessageBox("�����ɹ�!");
		}
		catch (_com_error &e)
		{
	
			CString err;
			err.Format("ADO error:%s",(char*)e.Description());
			MessageBox(err);
			return ;
		}
		catch (CFileException* e)
		{
		}
		catch (CException* e)
		{
       }
	
	}

}

void CListDlg::Del()
{
	UpdateData();
	try
	{
		_variant_t vstrsex;
		vstrsex.iVal=m_sex;
		CString strid;
		((CEdit*)GetDlgItem(IDC_EDIT1))->GetWindowText(strid);
		CString strsex;
		if( m_sex==0)
			strsex="0";
		else
			strsex="1";
		_variant_t var;
		var=m_date;
		
		CString strsql="delete from STUDENTS where SID="+strid;
		//MessageBox((_variant_t)strsql);
		if ( m_pOne->State==adStateOpen)
			m_pOne->Close();
		m_pOne->Open((_variant_t)strsql,
			//m_pcon.GetInterfacePtr(),
			//theApp.m_pCon.GetInterfacePtr(),
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenStatic,
			adLockOptimistic,
			adCmdUnknown);
		MessageBox("ɾ���ɹ�!");
	}
	catch (_com_error &e)
	{
		
		CString err;
		err.Format("ADO error:%s",(char*)e.Description());
		MessageBox(err);
		return ;
		}
}

void CListDlg::Upd()
{
	UpdateData();
	try
	{
		_variant_t vstrsex;
		vstrsex.iVal=m_sex;
		CString strid;
		((CEdit*)GetDlgItem(IDC_EDIT1))->GetWindowText(strid);
		CString strsex;
		if( m_sex==0)
			strsex="0";
		else
			strsex="1";
		_variant_t var;
		var=m_date;
		
		CString strsql="update STUDENTS set SName='"+m_sname+"',SSex="+strsex+",SComeDate=" + (char*)(_bstr_t)var.date + "-2 where SID="+strid;
		//MessageBox((_variant_t)strsql);
		if ( m_pOne->State==adStateOpen)
			m_pOne->Close();
		m_pOne->Open((_variant_t)strsql,
			//m_pcon.GetInterfacePtr(),
			//theApp.m_pCon.GetInterfacePtr(),
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenStatic,
			adLockOptimistic,
			adCmdUnknown);
		MessageBox("�޸ĳɹ�!");
	}
	catch (_com_error &e)
	{
		
		CString err;
		err.Format("ADO error:%s",(char*)e.Description());
		MessageBox(err);
		return ;
		}

}

void CListDlg::Select()
{
	m_pOne.CreateInstance(__uuidof(Recordset));
	UpdateData();

	try
	{
		//��SQL���ݿ��д�STUDENTS��
		//	m_pcon->Open("driver={SQL Server};Server=(local);DATABASE=UGMS;UID=sa;PWD=sa","","",adModeUnknown);
		CString strsql;
		_variant_t _vr;
		_vr.iVal=m_sid;
		CString strid;
		((CEdit*)GetDlgItem(IDC_EDIT1))->GetWindowText(strid);
		strsql="SELECT SID,SName, case SSex when 0 then '��' else 'Ů' end   SSex,convert(varchar(10),SComeDate,121) SComeDate FROM STUDENTS where sid like '%'+'"+strid+"%'";
	     //strsql.Format("SELECT SID,SName, SSex,SComeDate FROM STUDENTS where sid like '%"+"%s""%'",strid);
		m_pOne->Open((_variant_t)strsql, 
			//m_pcon.GetInterfacePtr(),
			//theApp.m_pCon.GetInterfacePtr(),
			theApp.m_pConnection.GetInterfacePtr(),
			adOpenDynamic,
			adLockOptimistic,
			adCmdText);
		
	}
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}

	UpdateData(FALSE);
	m_list.DeleteAllItems();
	while(!m_pOne->adoEOF)
	{
		int iItemCnt=0;
		iItemCnt=m_list.GetItemCount();
		m_list.InsertItem(iItemCnt,(_bstr_t)m_pOne->GetCollect("SID"));
		m_list.SetItemText(iItemCnt,1,(_bstr_t)m_pOne->GetCollect("SName"));
		m_list.SetItemText(iItemCnt,2,(_bstr_t)m_pOne->GetCollect("SSex"));
		m_list.SetItemText(iItemCnt,3,(_bstr_t)m_pOne->GetCollect("SComeDate"));
		
		m_pOne->MoveNext();		
	}

	if(!m_pOne ->BOF)
	{		
		m_pOne->MoveFirst();
	}
	else
	{
		MessageBox("û������!");
		return ;
	}	
	




}

void CListDlg::OnbtnCancel() 
{
	// TODO: Add your control notification handler code here
	m_btnSelect.EnableWindow(TRUE);
	m_btnNew.EnableWindow(TRUE);
	m_btnUpd.EnableWindow(TRUE);	
	m_btnDel.EnableWindow(TRUE);
}

void CListDlg::OnbtnSave() 
{
	//UpdateData(TRUE);
	// TODO: Add your control notification handler code here
	if (FOUNCTION==add)
	{
		Add();
	}
	if(FOUNCTION==MODIFY)
	{

		Upd();
	}
	if(FOUNCTION ==DEL)
	{
		Del();
	}
}

void CListDlg::OnClickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	irow=m_list.GetSelectionMark();
	*pResult = 0;
}
